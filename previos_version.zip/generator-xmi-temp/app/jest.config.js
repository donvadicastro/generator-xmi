const rootConfig = require('../jest.base');

module.exports = { ...rootConfig };
