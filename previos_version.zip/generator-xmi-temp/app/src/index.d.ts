declare const XmiGenerator_base: new (args: any, opts: any) => any;
export declare class XmiGenerator extends XmiGenerator_base {
    dist: string;
    testFiles: string[];
    generatedFiles: string[];
    collaborationDiagrams: any[];
    constructor(args: any, opts: any);
    prompting(): void;
    clean(): void;
    generate(): void;
    _readData(callback: (result: any) => void): void;
}
export {};
