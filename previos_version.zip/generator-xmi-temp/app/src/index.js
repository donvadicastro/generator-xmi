'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
exports.XmiGenerator = void 0;
const tslib_1 = require("tslib");
const generator_xmi_core_1 = require("generator-xmi-core");
const chalk_1 = require("chalk");
const xml2js_1 = require("xml2js");
const Generator = require("yeoman-generator");
const yosay = require("yosay");
const treeify = require("treeify");
const shell = require("shelljs");
class XmiGenerator extends Generator {
    constructor(args, opts) {
        super(args, opts);
        this.dist = 'dist';
        this.testFiles = [];
        this.generatedFiles = [];
        this.collaborationDiagrams = [];
        this.argument('xmiFileName', { type: String, required: true });
        this.option('destination', { type: String, default: 'dist' });
        this.option('type', { type: String, default: 'nodejs' });
        this.option('auth', { type: Boolean, default: false });
        this.option('dryRun', { type: Boolean, default: false });
    }
    prompting() {
        this.log(yosay(`Welcome to ${(0, chalk_1.red)('XMI')} generator!`));
        this.log((0, chalk_1.green)('Options'));
        this.log('file           : ' + this.options.xmiFileName);
        this.log('destination    : ' + this.destinationPath(this.options.destination));
        this.log('type           : ' + this.options.type);
        this.log('auth           : ' + this.options.auth ? 'yes' : 'no');
        this.log('dryRun         : ' + this.options.dryRun ? 'yes' : 'no');
    }
    clean() {
        shell.rm('-rf', `${this.options.destination}/api`);
        shell.rm('-rf', `${this.options.destination}/app`);
    }
    generate() {
        const done = this.async();
        this._readData((result) => tslib_1.__awaiter(this, void 0, void 0, function* () {
            const parser = new generator_xmi_core_1.XmiParser(result);
            const success = yield parser.parse({ 'nodejs': 'js', 'spring': 'java' }[this.options.type]);
            this.log((0, chalk_1.green)('Model'));
            this.log(treeify.asTree(parser.toConsole(), true, true));
            if (success && !this.options.dryRun) {
                this.composeWith(Promise.resolve().then(() => require('../' + this.options.type)), Object.assign(Object.assign({}, this.options), { parser: parser }));
            }
            done();
        }));
    }
    _readData(callback) {
        const file = this.fs.read(this.options.xmiFileName);
        (0, xml2js_1.parseString)(file, (err, result) => {
            // this.fs.writeJSON(this.templatePath('../files/test.json'), result);
            callback(result);
        });
    }
}
exports.XmiGenerator = XmiGenerator;
module.exports = XmiGenerator;
//# sourceMappingURL=index.js.map
