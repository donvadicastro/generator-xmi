export * from "./dialectType";
export * from "./linkType";
