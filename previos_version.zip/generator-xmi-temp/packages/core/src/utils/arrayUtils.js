"use strict";
exports.__esModule = true;
exports.ArrayUtils = void 0;
var ArrayUtils = /** @class */ (function () {
    function ArrayUtils() {
    }
    ArrayUtils.insertIfNotExists = function (entity, array) {
        array.indexOf(entity) >= 0 || array.push(entity);
    };
    return ArrayUtils;
}());
exports.ArrayUtils = ArrayUtils;
