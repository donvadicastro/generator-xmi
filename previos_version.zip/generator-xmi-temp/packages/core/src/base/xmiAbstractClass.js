"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
exports.__esModule = true;
exports.xmiAbstractClass = void 0;
var xmiInterface_1 = require("../entities/xmiInterface");
var xmiAggregationLink_1 = require("../entities/links/xmiAggregationLink");
var arrayUtils_1 = require("../utils/arrayUtils");
var assert = require('assert');
var xmiAbstractClass = /** @class */ (function (_super) {
    __extends(xmiAbstractClass, _super);
    function xmiAbstractClass(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        _this.links = { sequence: [], usage: [], aggregation: [], association: [], generalization: [], realization: [] };
        /**
         * Diagram fragments that class associate with.
         */
        _this.fragments = [];
        /**
         * Set of conditions that can be defined in diagram to particular operation.
         */
        _this.conditions = {};
        if (raw.links && raw.links.length && raw.links[0].Aggregation) {
            _this.links.aggregation = raw.links[0].Aggregation.map(function (x) { return new xmiAggregationLink_1.xmiAggregationLink(x, _this, factory); });
        }
        if (raw.links && raw.links.length && raw.links[0].Association) {
            _this.links.association = raw.links[0].Association.map(function (x) { return new xmiAggregationLink_1.xmiAggregationLink(x, _this, factory); });
        }
        if (raw.links && raw.links.length && raw.links[0].Generalization) {
            _this.links.generalization = raw.links[0].Generalization.map(function (x) { return new xmiAggregationLink_1.xmiAggregationLink(x, _this, factory); });
        }
        if (raw.links && raw.links.length && raw.links[0].Realisation) {
            _this.links.realization = raw.links[0].Realisation.map(function (x) { return new xmiAggregationLink_1.xmiAggregationLink(x, _this, factory); });
        }
        return _this;
    }
    Object.defineProperty(xmiAbstractClass.prototype, "aggregationLinks", {
        /**
         * Two-way connections between elements, ignoring arrow direction
         */
        get: function () {
            return this.getConnections('aggregation');
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiAbstractClass.prototype, "associationLinks", {
        /**
         * Two-way connections between elements, ignoring arrow direction
         */
        get: function () {
            return this.getConnections('association');
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiAbstractClass.prototype, "generalizationLinks", {
        /**
         * Two-way connections between elements, ignoring arrow direction
         */
        get: function () {
            return this.getConnections('generalization');
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiAbstractClass.prototype, "realizationLinks", {
        /**
         * Realization one-way connection
         */
        get: function () {
            return this.getConnections('realization');
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiAbstractClass.prototype, "generalizationLinksFrom", {
        /**
         * Generalization links, when arrow to current element
         */
        get: function () {
            var _this = this;
            return this.links.generalization.filter(function (x) { return x.end === _this; }).map(function (x) { return x.start; });
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiAbstractClass.prototype, "generalizationLinksTo", {
        /**
         * Generalization link, when arrow from current element
         */
        get: function () {
            var _this = this;
            var links = this.generalization ?
                this.links.generalization.filter(function (x) { return x.start === _this; }) : [];
            assert(links.length <= 1, "Class \"".concat(this.nameOrigin, "\" can have no more than 1 generalization links. Current: ").concat(links.length));
            return links.length ? links[0].end : null;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiAbstractClass.prototype, "implements", {
        /**
         * Generalization links, when arrow to current element
         */
        get: function () {
            var _this = this;
            return this.links.realization.filter(function (x) { return x.end === _this; }).map(function (x) { return x.start; });
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiAbstractClass.prototype, "hasLoop", {
        /**
         * Indicates that class has associated loop.
         */
        get: function () {
            return this.fragments.find(function (x) { return x.interactionOperator === 'loop'; });
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiAbstractClass.prototype, "attributesCombined", {
        /**
         * Returns all entity attributes including added relation properties
         */
        get: function () {
            var _this = this;
            var attributes = [];
            attributes = attributes.concat(this.attributes);
            attributes = attributes.concat(__spreadArray(__spreadArray([], this.getConnections('aggregation'), true), this.getConnections('association'), true).map(function (x) { return ((!x.target.multiplicity || x.target.multiplicity === '1' || x.target.multiplicity === '0..1') ? {
                name: x.target.typeRef.name + 'Ref',
                typeRef: x.target.typeRef,
                isArray: false,
                isOptional: x.target.multiplicity === '0..1',
                //indicate if link to the parent in relation (composition, aggregation)
                isParent: x.source.typeRef === _this && x.target.aggregation !== 'none',
                linkType: x[x.target.aggregation === 'none' ? 'source' : 'target'].aggregation,
                typeDefaultValue: 'null'
            } : {
                name: x.target.typeRef.name + 'RefList',
                typeRef: x.target.typeRef,
                isArray: true
            }); }));
            return attributes;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiAbstractClass.prototype, "attributesCombinedToEdit", {
        /**
         * Get all attributes that are used to edit entity content (main usage is form editing).
         */
        get: function () {
            var attrs = this.attributesCombined;
            if (this.generalizationLinksTo) {
                attrs = attrs.concat(this.generalizationLinksTo.attributesCombinedToEdit);
            }
            return attrs.filter(function (x) { return x.name && !x.isParent; });
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiAbstractClass.prototype, "references", {
        get: function () {
            var imports = _super.prototype.references;
            //Inject generalization references
            if (this.generalizationLinksTo) {
                arrayUtils_1.ArrayUtils.insertIfNotExists(this.generalizationLinksTo, imports);
            }
            //Inject base interface when instance specification is used
            this.associationLinks.forEach(function (x) { return arrayUtils_1.ArrayUtils.insertIfNotExists(x.target.typeRef, imports); });
            this.aggregationLinks.forEach(function (x) { return arrayUtils_1.ArrayUtils.insertIfNotExists(x.target.typeRef, imports); });
            return imports;
        },
        enumerable: false,
        configurable: true
    });
    xmiAbstractClass.prototype.toConsole = function () {
        var ret = _super.prototype.toConsole.call(this);
        ret[Object.keys(ret)[0]].conditions = this.conditions;
        return ret;
    };
    xmiAbstractClass.prototype.getConnections = function (type) {
        var _this = this;
        return this.links[type].map(function (x) { return x.connector.getDirectedFrom(_this); });
    };
    return xmiAbstractClass;
}(xmiInterface_1.xmiInterface));
exports.xmiAbstractClass = xmiAbstractClass;
