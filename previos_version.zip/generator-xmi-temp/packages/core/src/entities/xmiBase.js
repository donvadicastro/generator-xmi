"use strict";
exports.__esModule = true;
var object_path_1 = require("object-path");
var rxjs_1 = require("rxjs");
var typeConverter_1 = require("../utils/typeConverter");
var camel = require('to-camel-case');
var pascal = require('to-pascal-case');
/**
 * XMI primitive definition.
 *
 * Contains only basic fields that any XMI element should have.
 * If factory can't recognize nature of the element - base is created to track for possible usage.
 */
var xmiBase = /** @class */ (function () {
    function xmiBase(raw, parent, factory) {
        var _this = this;
        this.comments = [];
        this.tags = {};
        /**
         * Trigger event when element is resolved
         * @param x resolved element
         */
        this.onAfterInit = new rxjs_1.ReplaySubject();
        this._factory = factory;
        this._raw = raw;
        this.parent = parent;
        this.id = this._raw.$['xmi:id'] || this._raw.$['xmi:ifrefs'] || this._raw.$['xmi:idref'];
        this.typeId = this._raw.$['xmi:type'];
        this.nameOrigin = this._raw.$.name;
        this.name = this.nameOrigin && camel(this.nameOrigin);
        this.namePascal = this.nameOrigin && pascal(this.nameOrigin);
        this.description = (0, object_path_1.get)(this._raw, ['properties', '0', '$', 'documentation']);
        this.alias = (0, object_path_1.get)(this._raw, ['properties', '0', '$', 'alias']);
        this.alias && (this.alias = this.alias.split('.').map(function (x) { return camel(x); }).join('.'));
        this.stereotype = (0, object_path_1.get)(this._raw, ['properties', '0', '$', 'stereotype']);
        //parse comments
        this.comments = (0, object_path_1.get)(raw, 'ownedComment', []).map(function (x) { return _this._factory.get(x); });
        //parse tags
        this.tags = (raw.tags || []).reduce(function (prev, current) {
            var tag = (0, object_path_1.get)(current, 'tag.0.$');
            tag && (prev[tag.name] = tag.value);
            return prev;
        }, {});
    }
    /**
     * Notify element fully initialized.
     */
    xmiBase.prototype.initialized = function () {
        this.onAfterInit.next(this);
        this.onAfterInit.complete();
    };
    Object.defineProperty(xmiBase.prototype, "className", {
        /**
         * Gets instantiated element class name.
         */
        get: function () {
            return this.constructor.name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiBase.prototype, "pathFromRoot", {
        /**
         * Gets path from root to this element using file hierarchy path representation, e.g. "parent1/parent2/parent3"
         */
        get: function () {
            return this.pathToRoot.slice(0, this.pathToRoot.length - 1).reverse();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiBase.prototype, "pathToRoot", {
        /**
         * Gets list of parent elements up to root.
         */
        get: function () {
            var path = [];
            var parent = this.parent;
            while (parent) {
                path.push(parent);
                parent = parent.parent;
            }
            return path;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Gets stringified path from root to current element.
     * @param modifier name modifier function (takes names as inout and produce changed name as output).
     *  Returns same input by default.
     * @param concat concatenator, default "/"
     */
    xmiBase.prototype.getPathFromRoot = function (modifier, concat) {
        if (modifier === void 0) { modifier = function (x) { return x; }; }
        if (concat === void 0) { concat = '/'; }
        return this.pathFromRoot.map(function (x) { return x.name; }).map(function (x) { return modifier(x); }).join(concat);
    };
    /**
     * Gets stringified relative path to element, e.g. "../../parent1/parent2"
     * @param element element to build path to
     */
    xmiBase.prototype.getRelativePath = function (element) {
        return this.pathToRoot.map(function (x) { return '..'; }).join('/') + '/' +
            element.pathToRoot.slice(0, element.pathToRoot.length - 1).reverse().map(function (x) { return x.name; }).join('/');
    };
    /**
     * Gets relative root path, e.g. "../../"
     */
    xmiBase.prototype.getRelativeRoot = function () {
        return this.pathToRoot.map(function (x) { return '..'; }).join('/');
    };
    Object.defineProperty(xmiBase.prototype, "elementId", {
        /**
         * Gets element user friendly unique identifier.
         */
        get: function () {
            return "".concat(this.getPathFromRoot(function (input) { return input; }, '_'), "_").concat(this.name);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiBase.prototype, "type", {
        /**
         * Gets actual type (using language qualifier).
         */
        get: function () {
            return typeConverter_1.TypeConverter.getType(this.typeId, this._factory.dialect);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiBase.prototype, "references", {
        /**
         * Gets all referenced entities for particular instance.
         */
        get: function () {
            return [];
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Refresh element.
     * @param raw actual raw.
     * @param parent actual parent element.
     */
    xmiBase.prototype.refreshBase = function (raw, parent) {
        if (parent) {
            this.parent = this.parent || parent;
        }
    };
    /**
     * Gets console element view.
     */
    xmiBase.prototype.toConsole = function () {
        return "[".concat(this.typeId, "] ").concat(this.name, " (").concat(this.id, ")");
    };
    return xmiBase;
}());
exports["default"] = xmiBase;
