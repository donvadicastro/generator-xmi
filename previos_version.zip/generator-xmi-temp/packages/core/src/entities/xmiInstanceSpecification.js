"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiInstanceSpecification = void 0;
var xmiAbstractClass_1 = require("../base/xmiAbstractClass");
var arrayUtils_1 = require("../utils/arrayUtils");
var xmiInstanceSpecification = /** @class */ (function (_super) {
    __extends(xmiInstanceSpecification, _super);
    function xmiInstanceSpecification() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(xmiInstanceSpecification.prototype, "elementRef", {
        get: function () {
            return this._factory.getByKey(this._raw.$.classifier);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiInstanceSpecification.prototype, "references", {
        get: function () {
            var imports = _super.prototype.references;
            //Inject base class when instance specification is used
            if (this.elementRef) {
                arrayUtils_1.ArrayUtils.insertIfNotExists(this.elementRef, imports);
            }
            return imports;
        },
        enumerable: false,
        configurable: true
    });
    return xmiInstanceSpecification;
}(xmiAbstractClass_1.xmiAbstractClass));
exports.xmiInstanceSpecification = xmiInstanceSpecification;
