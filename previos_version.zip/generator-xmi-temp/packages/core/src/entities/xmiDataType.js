"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiDataType = void 0;
var xmiInterface_1 = require("./xmiInterface");
var arrayUtils_1 = require("../utils/arrayUtils");
var xmiDataType = /** @class */ (function (_super) {
    __extends(xmiDataType, _super);
    function xmiDataType() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(xmiDataType.prototype, "references", {
        get: function () {
            var imports = _super.prototype.references;
            //Inject attributes type
            this.attributes.forEach(function (attribute) { return attribute.typeRef && arrayUtils_1.ArrayUtils.insertIfNotExists(attribute, imports); });
            return imports;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiDataType.prototype, "attributesCombinedToEdit", {
        /**
         * Get all attributes that are used to edit entity content (main usage is form editing).
         */
        get: function () {
            return this.attributes;
        },
        enumerable: false,
        configurable: true
    });
    return xmiDataType;
}(xmiInterface_1.xmiInterface));
exports.xmiDataType = xmiDataType;
