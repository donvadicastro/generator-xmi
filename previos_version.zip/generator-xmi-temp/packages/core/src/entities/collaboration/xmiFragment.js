"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiFragment = void 0;
var xmiBase_1 = require("../xmiBase");
var rxjs_1 = require("rxjs");
var xmiFragment = /** @class */ (function (_super) {
    __extends(xmiFragment, _super);
    function xmiFragment(raw, parent, factory, lifelines) {
        var _this = _super.call(this, raw, parent, factory) || this;
        /**
         * Links to operands in combined fragments when this entity belongs to.
         */
        _this.operands = [];
        _this.interactionOperator = raw.$.interactionOperator;
        // get covered id's as list, clean duplicates
        var covered = (raw.$.covered ? [raw.$.covered] : raw.covered.map(function (x) { return x.$['xmi:idref']; }))
            .filter(function (x, i, arr) { return arr.indexOf(x) === i; });
        _this.lifelines = lifelines.filter(function (x) { return covered.indexOf(x.id) >= 0; });
        (0, rxjs_1.forkJoin)(covered.map(function (x) { return _this._factory.resolveById(x); })).subscribe(function (result) {
            (0, rxjs_1.forkJoin)(result.map(function (y) { return y.onAfterInit; })).subscribe(function (initialized) {
                initialized.forEach(function (i) {
                    _this.lifelines.indexOf(i) >= 0 || _this.lifelines.push(i);
                    if (_this.interactionOperator) {
                        i.elementRef.fragments.indexOf(_this) >= 0 || i.elementRef.fragments.push(_this); // add lifelines to referenced fragments
                    }
                });
                _this.initialized();
            });
        });
        return _this;
    }
    return xmiFragment;
}(xmiBase_1["default"]));
exports.xmiFragment = xmiFragment;
