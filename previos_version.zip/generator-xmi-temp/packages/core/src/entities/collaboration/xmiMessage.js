"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiMessage = void 0;
var xmiBase_1 = require("../xmiBase");
var rxjs_1 = require("rxjs");
var assert = require('assert');
var xmiMessage = /** @class */ (function (_super) {
    __extends(xmiMessage, _super);
    function xmiMessage(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        //set reference to source when condition is used
        if (_this.connector.condition) {
            (0, rxjs_1.forkJoin)([_this.fromSource.onAfterInit, _this.toSource.onAfterInit])
                .subscribe(function () {
                assert(_this.from, "Source component for message \"".concat(_this.name, "\" not exists"));
                assert(_this.to, "Target component for message \"".concat(_this.name, "\" not exists"));
                (0, rxjs_1.forkJoin)([_this.from.onAfterInit, _this.to.onAfterInit]).subscribe(function (val) {
                    assert(_this.from.elementRef, "Source component reference for message \"".concat(_this.name, "\" not exists"));
                    assert(_this.to.elementRef, "Target component reference for message \"".concat(_this.name, "\" not exists"));
                    //link condition with operation that will be affected by this condition.
                    var key = "".concat(_this.to.elementRef.name, "_").concat(_this.operation.name);
                    _this.from.elementRef.conditions[key] || (_this.from.elementRef.conditions[key] = []);
                    _this.from.elementRef.conditions[key].push(_this.connector.condition);
                });
            });
        }
        return _this;
    }
    Object.defineProperty(xmiMessage.prototype, "fromSource", {
        /**
         * Source for FROM fragment
         * @private
         */
        get: function () {
            var _this = this;
            return this._factory.fragmentHash.filter(function (x) { return x.id === _this._raw.$.sendEvent; })[0];
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiMessage.prototype, "toSource", {
        /**
         * Source for TO fragment
         * @private
         */
        get: function () {
            var _this = this;
            return this._factory.fragmentHash.filter(function (x) { return x.id === _this._raw.$.receiveEvent; })[0];
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiMessage.prototype, "operation", {
        get: function () {
            var _this = this;
            return this.to && this.to.elementRef && this.to.elementRef.operations.filter(function (x) { return x.id === _this._raw.$.signature; })[0];
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiMessage.prototype, "from", {
        get: function () {
            var f = this.fromSource;
            return f && f.lifelines[0];
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiMessage.prototype, "fromOperand", {
        /**
         * Get operand in combined fragment where this start message belongs to (e.g. loop)
         */
        get: function () {
            var f = this.fromSource;
            return (f && f.operands.length) ? f.operands[0] : null;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiMessage.prototype, "to", {
        get: function () {
            var f = this.toSource;
            return f && f.lifelines[0];
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiMessage.prototype, "toOperand", {
        /**
         * Get operand in combined fragment where this end message belongs to (e.g. loop)
         */
        get: function () {
            var f = this.toSource;
            return (f && f.operands.length) ? f.operands[0] : null;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiMessage.prototype, "connector", {
        get: function () {
            return this._factory.connectorHash[this.id];
        },
        enumerable: false,
        configurable: true
    });
    xmiMessage.prototype.toConsole = function () {
        var _a;
        this.from && assert(this.from.elementRef, "Null ref for message \"".concat(this.name, "\": from \"").concat(this.from.elementRef.name, "\" (").concat(this.from.elementRef.id, ")"));
        this.to && assert(this.to.elementRef, "Null ref for message \"".concat(this.name, "\": to \"").concat(this.to.elementRef.name, "\" (").concat(this.to.elementRef.id, ")"));
        assert(this.operation, "Operation should be specified for \"".concat(this.to && this.to.elementRef.name, "\" component: ").concat(this.pathToRoot.map(function (x) { return x.name; }).join(' -> ')));
        assert(this.connector, "Connector should be attached to message \"".concat(this.name, "\""));
        return _a = {}, _a[this.name] = "".concat(this.id, " (").concat(this.from && this.from.elementRef.name, " - ").concat(this.to && this.to.elementRef.name, "::").concat(this.operation.name, ")"), _a;
    };
    return xmiMessage;
}(xmiBase_1["default"]));
exports.xmiMessage = xmiMessage;
