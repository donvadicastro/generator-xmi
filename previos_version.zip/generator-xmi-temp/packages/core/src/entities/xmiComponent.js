"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiComponent = void 0;
var xmiRequired_1 = require("./component/xmiRequired");
var xmiAbstractClass_1 = require("../base/xmiAbstractClass");
var rxjs_1 = require("rxjs");
var arrayUtils_1 = require("../utils/arrayUtils");
var xmiComponent = /** @class */ (function (_super) {
    __extends(xmiComponent, _super);
    function xmiComponent(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        _this.provided = [];
        _this.required = [];
        _this.connectors = [];
        _this.refreshComponent(raw);
        return _this;
    }
    xmiComponent.prototype.refreshComponent = function (raw, parent) {
        var _this = this;
        _super.prototype.refresh.call(this, raw, parent);
        if (raw.links && raw.links.length && raw.links[0].Sequence) {
            this.links.sequence = raw.links[0].Sequence.map(function (x) { return _this._factory.getLink(x, _this); });
        }
        if (raw.links && raw.links.length && raw.links[0].Usage) {
            this.links.usage = raw.links[0].Usage.map(function (x) { return _this._factory.getLink(x, _this); });
        }
        if (raw.provided) {
            this.provided = raw.provided.map(function (x) { return _this._factory.registerProvide(x, _this); });
        }
        if (raw.required) {
            this.required = raw.required.map(function (x) { return new xmiRequired_1.xmiRequired(x, _this, _this._factory); });
        }
        if (raw.ownedConnector) {
            this.connectors = raw.ownedConnector.map(function (x) { return _this._factory.getConnectorByKey(x.$['xmi:id']); });
            // connector source/target not yet fully initialized
            (0, rxjs_1.forkJoin)(this.connectors.map(function (x) { return x.onAfterInit; })).subscribe(function () {
                _this.connectors.forEach(function (x) {
                    var dep = _this.createDependencyLinkByConnector(x, parent);
                    _this.required.push(dep);
                    x.target.typeRef.provided.push(dep);
                });
            });
        }
    };
    Object.defineProperty(xmiComponent.prototype, "references", {
        get: function () {
            var imports = _super.prototype.references;
            this.provided.filter(function (x) { return x.typeRef; }).forEach(function (value) {
                var ref = value.typeRef;
                arrayUtils_1.ArrayUtils.insertIfNotExists(ref, imports);
                (ref.attributes || []).filter(function (x) { return x.typeRef; }).forEach(function (attribute) {
                    var typeRef = attribute.typeRef;
                    arrayUtils_1.ArrayUtils.insertIfNotExists(typeRef, imports);
                });
            });
            this.required.forEach(function (value) {
                var typeRef = value.typeRef;
                arrayUtils_1.ArrayUtils.insertIfNotExists(typeRef, imports);
            });
            return imports;
        },
        enumerable: false,
        configurable: true
    });
    xmiComponent.prototype.toConsole = function () {
        var ret = _super.prototype.toConsole.call(this);
        var key = Object.keys(ret)[0];
        this.required && (ret[key].required = this.required.map(function (x) { return x.name; }));
        this.provided && (ret[key].provided = this.provided.map(function (x) { return x.name; }));
        this.connectors && (ret[key].connectors = this.connectors.map(function (x) { return x.id; }));
        return ret;
    };
    xmiComponent.prototype.createDependencyLinkByConnector = function (connector, parent) {
        var typeRef = connector.target.typeRef;
        var identifiers = { $: { 'xmi:id': typeRef.id, 'xmi:idref': typeRef.id } };
        var dep = new xmiRequired_1.xmiRequired(identifiers, this, this._factory);
        //dep.typeRef = typeRef;
        //dep.linkRef = new xmiInOut(identifiers, parent || null, this._factory);
        return dep;
    };
    return xmiComponent;
}(xmiAbstractClass_1.xmiAbstractClass));
exports.xmiComponent = xmiComponent;
