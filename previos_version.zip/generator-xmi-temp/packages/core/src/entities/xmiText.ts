import xmiBase from "./xmiBase";

export class xmiText extends xmiBase {
}
