"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiCollaboration = void 0;
var xmiBase_1 = require("./xmiBase");
var object_path_1 = require("object-path");
var xmiAttribute_1 = require("./class/xmiAttribute");
var rxjs_1 = require("rxjs");
var arrayUtils_1 = require("../utils/arrayUtils");
var assert = require('assert');
var xmiCollaboration = /** @class */ (function (_super) {
    __extends(xmiCollaboration, _super);
    function xmiCollaboration(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        _this.fragments = [];
        _this.messages = [];
        _this.attributes = (_this._raw.ownedAttribute || [])
            .map(function (x) { return new xmiAttribute_1.xmiAttribute(x, _this, factory); });
        _this.lifelines = (0, object_path_1.get)(_this._raw, 'ownedBehavior.0.lifeline', [])
            .map(function (x) { return _this._factory.get(x, _this, _this.attributes); });
        _this.fragments = (0, object_path_1.get)(_this._raw, 'ownedBehavior.0.fragment', [])
            .map(function (x) { return _this._factory.get(x, _this, _this.lifelines); });
        _this.messages = (0, object_path_1.get)(_this._raw, 'ownedBehavior.0.message', [])
            .map(function (x) {
            var message = _this._factory.get(x, _this, _this.fragments);
            (0, rxjs_1.forkJoin)({
                from: message.from ? message.from.onAfterInit : (0, rxjs_1.of)(),
                to: message.to ? message.to.onAfterInit : (0, rxjs_1.of)()
            }).subscribe(function () {
                //when lifeline is not presenter in XMI, but message use
                if (message.from && !_this.lifelines.find(function (x) { return x.elementRef === message.from.elementRef; })) {
                    var lifeline = _this._factory.lifelineHash.find(function (x) { return x.elementRef === message.from.elementRef; });
                    assert(lifeline, "Lifeline for FROM (".concat(message.from.elementRef.name, ") object not exists: ").concat(_this.pathToRoot.map(function (x) { return x.name; }).join(' -> ')));
                    _this.lifelines.push(lifeline);
                }
                //when lifeline is not presenter in XMI, but message use
                if (message.to && !_this.lifelines.find(function (x) { return (x || {}).elementRef === message.to.elementRef; })) {
                    var lifeline = _this._factory.lifelineHash.find(function (x) { return x.elementRef === message.to.elementRef; });
                    assert(lifeline, "Lifeline for TO(".concat(message.to.elementRef.name, ") object not exists: ").concat(_this.pathToRoot.map(function (x) { return x.name; }).join(' -> ')));
                    _this.lifelines.push(lifeline);
                }
            });
            return message;
        });
        return _this;
    }
    xmiCollaboration.prototype.initialize = function () {
    };
    Object.defineProperty(xmiCollaboration.prototype, "loopFragments", {
        get: function () {
            return this.fragments.filter(function (x) { return x.type === 'uml:CombinedFragment' && x.interactionOperator === 'loop'; });
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiCollaboration.prototype, "conditionFragments", {
        get: function () {
            return this.fragments.filter(function (x) { return x.type === 'uml:CombinedFragment' && x.interactionOperator === 'alt'; });
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiCollaboration.prototype, "references", {
        get: function () {
            var imports = _super.prototype.references;
            this.lifelines.forEach(function (lifeline, index) {
                return arrayUtils_1.ArrayUtils.insertIfNotExists(lifeline.elementRef, imports);
            });
            return imports;
        },
        enumerable: false,
        configurable: true
    });
    xmiCollaboration.prototype.toConsole = function () {
        return {
            lifelines: this.lifelines.map(function (x) { return x.toConsole(); }),
            fragments: this.fragments.filter(function (x) { return x.name; }).map(function (x) { return x.toConsole(); }),
            messages: this.messages.map(function (x) { return x.toConsole(); })
        };
    };
    return xmiCollaboration;
}(xmiBase_1["default"]));
exports.xmiCollaboration = xmiCollaboration;
