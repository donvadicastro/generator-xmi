"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiInterface = void 0;
var xmiBase_1 = require("./xmiBase");
var xmiOperation_1 = require("./class/xmiOperation");
var object_path_1 = require("object-path");
var xmiGeneralization_1 = require("./connectors/xmiGeneralization");
var rxjs_1 = require("rxjs");
var arrayUtils_1 = require("../utils/arrayUtils");
var xmiInterface = /** @class */ (function (_super) {
    __extends(xmiInterface, _super);
    function xmiInterface(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        _this.attributes = [];
        _this.operations = [];
        _this.refresh(raw, parent);
        return _this;
    }
    Object.defineProperty(xmiInterface.prototype, "references", {
        /**
         * Get all referenced entities for particular instance.
         */
        get: function () {
            var imports = _super.prototype.references;
            //Inject attributes type
            this.attributes.forEach(function (attribute) {
                return attribute.typeRef && arrayUtils_1.ArrayUtils.insertIfNotExists(attribute.typeRef, imports);
            });
            //Inject operation parameters and return types
            this.operations.forEach(function (operation) {
                operation.returnParameter.typeRef &&
                    arrayUtils_1.ArrayUtils.insertIfNotExists(operation.returnParameter.typeRef, imports);
                //Inject operation input parameter types
                operation.inputParameters
                    .forEach(function (param) { return param.typeRef && arrayUtils_1.ArrayUtils.insertIfNotExists(param.typeRef, imports); });
            });
            return imports;
        },
        enumerable: false,
        configurable: true
    });
    xmiInterface.prototype.refresh = function (raw, parent) {
        var _this = this;
        _super.prototype.refreshBase.call(this, raw, parent);
        if (raw.ownedAttribute) {
            this.attributes = raw.ownedAttribute
                .map(function (x) { return _this._factory.get(x, _this); })
                .filter(function (x) { return x.name; });
        }
        else {
            this.attributes = (0, object_path_1.get)(raw, ['attributes', '0', 'attribute'], [])
                .map(function (x) { return _this._factory.get(x, _this); })
                .filter(function (x) { return x.name; });
        }
        if (raw.ownedOperation) {
            this.operations = raw.ownedOperation
                .map(function (x, i) { return _this.operations[i] ? _this.operations[i].refresh(x) : new xmiOperation_1.xmiOperation(x, _this, _this._factory); });
        }
        else {
            this.operations = (0, object_path_1.get)(raw, ['operations', '0', 'operation'], [])
                .map(function (x, i) { return _this.operations[i] ? _this.operations[i].refresh(x) : new xmiOperation_1.xmiOperation(x, _this, _this._factory); });
        }
        if (raw.generalization) {
            this.generalization = new xmiGeneralization_1.xmiGeneralization((0, object_path_1.get)(raw, 'generalization.0'), this, this._factory);
        }
        this.attributes.sort(function (a, b) { return a.name > b.name ? 1 : -1; });
        this.operations.sort(function (a, b) { return a.name > b.name ? 1 : -1; });
        (0, rxjs_1.forkJoin)(this.attributes.map(function (x) { return x.onAfterInit; }))
            .subscribe(function () { return _this.initialized(); });
        return this;
    };
    xmiInterface.prototype.toConsole = function () {
        var _a;
        var key = _super.prototype.toConsole.call(this);
        var ret = (_a = {}, _a[key] = {}, _a);
        this.attributes.length && (ret[key].attributes = this.attributes.map(function (x) {
            var _a;
            return (_a = {}, _a[x.name] = (x.typeRef ? "".concat(x.typeRef.name, "(").concat(x.typeId, ")") : x.typeId), _a);
        }));
        this.operations.length && (ret[key].operations = this.operations
            .reduce(function (prev, x) {
            var returnParameter = x.parameters.find(function (x) { return x.name === 'return'; });
            prev["".concat(x.name, "(").concat(x.parameters.filter(function (x) { return x.name !== 'return'; }).map(function (x) { return x.name; }).join(','), ")")] =
                returnParameter ? "".concat(returnParameter.typeRef ? returnParameter.typeRef.name : returnParameter.type).concat(x.isReturnArray ? '[]' : '') : 'void';
            return prev;
        }, {}));
        return ret;
    };
    return xmiInterface;
}(xmiBase_1["default"]));
exports.xmiInterface = xmiInterface;
