"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiAttribute = void 0;
var assert_1 = require("assert");
var object_path_1 = require("object-path");
var xmiBase_1 = require("../xmiBase");
var typeConverter_1 = require("../../utils/typeConverter");
var xmiEnumeration_1 = require("../xmiEnumeration");
var xmiDataType_1 = require("../xmiDataType");
var _ = require("lodash");
var xmiAttribute = /** @class */ (function (_super) {
    __extends(xmiAttribute, _super);
    function xmiAttribute(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        _this.typeDefaultValue = 'null';
        _this.typeAllowedValues = [];
        _this.isArray = false;
        _this.isEnum = false;
        _this.isDataType = false;
        _this.name = _this.name && _.camelCase(_this.name);
        _this.typeId = /*this.raw.$['xmi:idref'] || */
            (0, object_path_1.get)(raw, ['type', '0', '$', 'xmi:idref']) ||
                (0, object_path_1.get)(raw, ['type', '0', '$', 'href']) ||
                (0, object_path_1.get)(raw, ['properties', '0', '$', 'type']);
        (0, assert_1.strict)(_this.typeId, "Type should be specified for attribute \"".concat(_this.name, "\" in class \"").concat(parent && parent.name, "\""));
        _this.isArray = typeConverter_1.TypeConverter.isArray(_this.typeId);
        if (typeConverter_1.TypeConverter.isPrimitive(_this.typeId)) {
            _this.typeId = typeConverter_1.TypeConverter.convert(_this.typeId);
            _this.typeDefaultValue = _this.isArray ? [] : typeConverter_1.TypeConverter.getTypeDefaultValue(_this.type);
            _this.typeAllowedValues = typeConverter_1.TypeConverter.getTypeAllowedValues(_this.type);
        }
        else {
            _this._factory.resolveById(_this.typeId).subscribe(function (x) {
                _this.typeRef = x;
                _this.isEnum = (x instanceof xmiEnumeration_1.xmiEnumeration);
                _this.isDataType = (x instanceof xmiDataType_1.xmiDataType);
            });
        }
        return _this;
    }
    Object.defineProperty(xmiAttribute.prototype, "dbType", {
        get: function () {
            return { string: 'varchar', number: 'float4', boolean: 'boolean', 'Date': 'timestamp' }[this.type];
        },
        enumerable: false,
        configurable: true
    });
    return xmiAttribute;
}(xmiBase_1["default"]));
exports.xmiAttribute = xmiAttribute;
