"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiParameter = void 0;
var xmiBase_1 = require("../xmiBase");
var typeConverter_1 = require("../../utils/typeConverter");
var assert = require('assert');
var xmiParameter = /** @class */ (function (_super) {
    __extends(xmiParameter, _super);
    function xmiParameter(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        _this.typeRef = undefined;
        _this.typeDefaultValue = 'null';
        /**
         * Indicates parameter is an array.
         */
        _this.isArray = false;
        _this.typeId = raw.$.type;
        assert(_this.typeId, "Type is not specified for parameter \"".concat(_this.name, "\" in operation \"").concat(parent.name, " -> ").concat(parent.pathToRoot.map(function (x) { return x.name; }).join(' -> '), "\""));
        _this.isArray = typeConverter_1.TypeConverter.isArray(_this.typeId) || _this.name.endsWith('List');
        if (typeConverter_1.TypeConverter.isPrimitive(_this.typeId)) {
            _this.typeId = typeConverter_1.TypeConverter.convert(_this.typeId);
            _this.typeDefaultValue = _this.isArray ? [] : typeConverter_1.TypeConverter.getTypeDefaultValue(_this.type);
        }
        else {
            _this._factory.resolveById(_this.typeId).subscribe(function (x) { return _this.typeRef = x; });
        }
        return _this;
    }
    return xmiParameter;
}(xmiBase_1["default"]));
exports.xmiParameter = xmiParameter;
