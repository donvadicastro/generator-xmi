"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiOperation = void 0;
var xmiBase_1 = require("../xmiBase");
var xmiParameter_1 = require("./xmiParameter");
var object_path_1 = require("object-path");
var camel = require('to-camel-case');
var assert = require('assert');
var xmiOperation = /** @class */ (function (_super) {
    __extends(xmiOperation, _super);
    function xmiOperation(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        _this.parameters = [];
        _this.isReturnArray = false;
        _this.refresh(raw);
        return _this;
    }
    Object.defineProperty(xmiOperation.prototype, "returnParameter", {
        get: function () {
            var returnParameter = this.parameters.find(function (x) { return x.name === 'return'; });
            assert(returnParameter, "Return parameter for operation \"".concat(this.name, "\" in class \"").concat(this.parent.name, "\" not defined"));
            //move return parameter into separate storage
            return returnParameter;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(xmiOperation.prototype, "inputParameters", {
        get: function () {
            return this.parameters.filter(function (x) { return x.name !== 'return'; });
        },
        enumerable: false,
        configurable: true
    });
    xmiOperation.prototype.refresh = function (raw) {
        var _this = this;
        this.name = this.name && camel(this.name);
        this.description = this.description || (0, object_path_1.get)(raw, 'documentation.0.$.value');
        this.parameters = (raw.ownedParameter || []).map(function (x) { return new xmiParameter_1.xmiParameter(x, _this, _this._factory); });
        if ((0, object_path_1.get)(raw, ['type', '0', '$', 'returnarray']) === '1') {
            this.isReturnArray = true;
        }
        return this;
    };
    return xmiOperation;
}(xmiBase_1["default"]));
exports.xmiOperation = xmiOperation;
