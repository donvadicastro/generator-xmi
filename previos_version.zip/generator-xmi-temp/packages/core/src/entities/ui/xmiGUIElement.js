"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiGUIElement = void 0;
var xmiBase_1 = require("../xmiBase");
var xmiUMLDiagram_1 = require("../diagrams/xmiUMLDiagram");
var arrayUtils_1 = require("../../utils/arrayUtils");
var assert = require('assert');
var xmiGUIElement = /** @class */ (function (_super) {
    __extends(xmiGUIElement, _super);
    function xmiGUIElement(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        _this.links = { informationFLow: [] };
        _this.children = [];
        if (raw.links && raw.links.length && raw.links[0].InformationFlow) {
            _this.links.informationFLow = raw.links[0].InformationFlow.map(function (x) { return _this._factory.getLink(x, _this); });
        }
        _this.properties = new Map((raw.tags[0].tag || []).map(function (x) { return [x.$.name, x.$.value]; }));
        _this.properties.set('label', raw.$.name);
        if (_this._raw.$['classifier']) {
            _this._factory.resolveById(_this._raw.$['classifier']).subscribe(function (x) { return _this.typeRef = x; });
        }
        _this.parseChildren(raw);
        return _this;
    }
    Object.defineProperty(xmiGUIElement.prototype, "references", {
        get: function () {
            var imports = _super.prototype.references;
            this.children.forEach(function (child, i) {
                var elementRef = child.links.informationFLow.length && child.links.informationFLow[0].end &&
                    child.links.informationFLow[0].end.elementRef;
                if (elementRef) {
                    arrayUtils_1.ArrayUtils.insertIfNotExists(elementRef, imports);
                    elementRef.lifelines.forEach(function (lifeline) { return arrayUtils_1.ArrayUtils.insertIfNotExists(lifeline.elementRef, imports); });
                }
            });
            return imports;
        },
        enumerable: false,
        configurable: true
    });
    xmiGUIElement.prototype.getInformationFlows = function (direction) {
        var _this = this;
        return this.links.informationFLow
            .filter(function (x) { return (direction === 'in' ? x.end : x.start) === _this; })
            .filter(function (x) { return (direction === 'in' ? x.start : x.end) instanceof xmiUMLDiagram_1.xmiUMLDiagram; });
    };
    xmiGUIElement.prototype.getCascadeFlows = function (direction) {
        var _this = this;
        return this.links.informationFLow
            .filter(function (x) { return (direction === 'in' ? x.end : x.start) === _this; })
            .filter(function (x) { return (direction === 'in' ? x.start : x.end) instanceof xmiGUIElement; });
    };
    xmiGUIElement.prototype.parseChildren = function (raw) {
        var _this = this;
        this.children = (raw.nestedClassifier || [])
            .map(function (x) { return _this._factory.get(x, _this); }).filter(function (x) { return x; });
        assert(this.children.map(function (x) { return x.name; })
            .every(function (x, index, arr) { return arr.indexOf(x) === index; }), "Control names on the \"".concat(this.name, "\" UI form should be unique: \"").concat(this.children.map(function (x) { return x.name; }), "\""));
    };
    xmiGUIElement.prototype.toConsole = function () {
        var _a;
        var _this = this;
        var key = _super.prototype.toConsole.call(this);
        var ret = (_a = {}, _a[key] = this.children.map(function (x) { return x.toConsole(); }) || [], _a);
        if (this.links.informationFLow.length) {
            ret[key].flowIn = this.getInformationFlows('in').map(function (x) {
                assert(x.start && x.start.elementRef, "Start for control \"".concat(_this.name, "\" in diagram \"").concat(_this.parent.pathToRoot.map(function (x) { return x.name; }).join(' -> '), "\" not specified"));
                return "-> ".concat(x.start && x.start.name, "(").concat(x.end && (x.end.elementRef || { name: '' }).name, ")");
            });
            ret[key].flowOut = this.getInformationFlows('out').map(function (x) {
                assert(x.end && x.end.elementRef, "End for control \"".concat(_this.name, "\" in diagram \"").concat(_this.parent.pathToRoot.map(function (x) { return x.name; }).join(' -> '), "\" not specified"));
                return "-> ".concat(x.end && x.end.name, "(").concat(x.end && (x.end.elementRef || { name: '' }).name, ")");
            });
        }
        return ret;
    };
    return xmiGUIElement;
}(xmiBase_1["default"]));
exports.xmiGUIElement = xmiGUIElement;
