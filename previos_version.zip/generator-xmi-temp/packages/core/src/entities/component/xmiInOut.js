"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiInOut = void 0;
var xmiBase_1 = require("../xmiBase");
var object_path_1 = require("object-path");
var xmiInOut = /** @class */ (function (_super) {
    __extends(xmiInOut, _super);
    function xmiInOut(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        _this.refresh(raw, parent);
        return _this;
    }
    xmiInOut.prototype.refresh = function (raw, parent) {
        var _this = this;
        var ownerId = (0, object_path_1.get)(raw, 'model.0.$.owner');
        if (ownerId) {
            this._factory.resolveById(ownerId).subscribe(function (x) { return _this.owner = x; });
        }
        return this;
    };
    return xmiInOut;
}(xmiBase_1["default"]));
exports.xmiInOut = xmiInOut;
