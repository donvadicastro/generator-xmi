"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiPackage = void 0;
var xmiBase_1 = require("./xmiBase");
var xmiPackage = /** @class */ (function (_super) {
    __extends(xmiPackage, _super);
    function xmiPackage(raw, parent, factory) {
        var _this = _super.call(this, raw, parent, factory) || this;
        _this.children = (raw.packagedElement || []).reverse()
            .map(function (x) { return _this._factory.get(x, _this); }).filter(function (x) { return x; }).reverse();
        return _this;
    }
    xmiPackage.prototype.getNode = function (path) {
        var node = this;
        path.split('.').forEach(function (x) {
            node = node && node.children.find(function (child) { return child.name === x; });
        });
        return node;
    };
    xmiPackage.prototype.toConsole = function () {
        var _a;
        return _a = {}, _a[_super.prototype.toConsole.call(this)] = this.children.map(function (x) { return x.toConsole(); }), _a;
    };
    return xmiPackage;
}(xmiBase_1["default"]));
exports.xmiPackage = xmiPackage;
