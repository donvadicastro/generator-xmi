"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.xmiAssociationParty = void 0;
var object_path_1 = require("object-path");
var xmiBase_1 = require("../xmiBase");
var xmiAssociationParty = /** @class */ (function (_super) {
    __extends(xmiAssociationParty, _super);
    function xmiAssociationParty(raw, factory) {
        var _this = _super.call(this, raw, null, factory) || this;
        _this.typeRef = undefined;
        _this.value = { lower: _this.getValue((0, object_path_1.get)(raw, 'lowerValue.0.$')), upper: _this.getValue((0, object_path_1.get)(raw, 'upperValue.0.$')) };
        _this.aggregation = raw.$['aggregation'];
        _this._factory.resolveById((0, object_path_1.get)(raw, 'type.0.$.xmi:idref')).subscribe(function (x) { return _this.typeRef = x; });
        return _this;
    }
    xmiAssociationParty.prototype.getValue = function (value) {
        switch ((value || {}).type) {
            case 'uml:LiteralInteger':
                value = parseInt(value.value);
                break;
            case 'uml:LiteralUnlimitedNatural':
                value = '*';
                break;
            default: break;
        }
        return value;
    };
    return xmiAssociationParty;
}(xmiBase_1["default"]));
exports.xmiAssociationParty = xmiAssociationParty;
