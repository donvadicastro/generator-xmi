"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var xmiConnectorParty_1 = require("./xmiConnectorParty");
var object_path_1 = require("object-path");
var xmiBase_1 = require("../xmiBase");
var rxjs_1 = require("rxjs");
var xmiConnector = /** @class */ (function (_super) {
    __extends(xmiConnector, _super);
    function xmiConnector(raw, factory) {
        var _this = _super.call(this, raw, null, factory) || this;
        _this.condition = (0, object_path_1.get)(raw, 'extendedProperties.0.$.conditional');
        _this.source = new xmiConnectorParty_1["default"](raw.source[0], factory);
        _this.target = new xmiConnectorParty_1["default"](raw.target[0], factory);
        // change resolve state once all children resolved
        (0, rxjs_1.forkJoin)({
            source: _this.source.onAfterInit,
            target: _this.target.onAfterInit
        }).subscribe(function () { return _this.initialized(); });
        return _this;
    }
    /**
     * Transform connector to be directed from defined connection party (consider as a source).
     * @param source
     */
    xmiConnector.prototype.getDirectedFrom = function (source) {
        return this.source.typeRef === source ? this :
            { condition: this.condition, source: this.target, target: this.source };
    };
    return xmiConnector;
}(xmiBase_1["default"]));
exports["default"] = xmiConnector;
