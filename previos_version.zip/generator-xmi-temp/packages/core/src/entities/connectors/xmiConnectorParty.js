"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var object_path_1 = require("object-path");
var xmiBase_1 = require("../xmiBase");
var xmiConnectorParty = /** @class */ (function (_super) {
    __extends(xmiConnectorParty, _super);
    function xmiConnectorParty(raw, factory) {
        var _this = _super.call(this, raw, null, factory) || this;
        _this.multiplicity = (0, object_path_1.get)(raw, 'type.0.$.multiplicity');
        _this.aggregation = (0, object_path_1.get)(raw, 'type.0.$.aggregation', 'none');
        _this._factory.resolveById(_this.id).subscribe(function (x) {
            _this.typeRef = x;
            _this.initialized();
        });
        return _this;
    }
    return xmiConnectorParty;
}(xmiBase_1["default"]));
exports["default"] = xmiConnectorParty;
