"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.XmiGeneratorBase = void 0;
const Generator = require('yeoman-generator');
const beautify = require('js-beautify').js;
const kebabCase = require('just-kebab-case');
class XmiGeneratorBase extends Generator {
    constructor() {
        super(...arguments);
        this.testFiles = [];
        this.generatedFiles = [];
        this.collaborationDiagrams = [];
        this.classes = [];
        this.dataTypes = [];
        this.enums = [];
        this.screens = [];
        this.components = [];
    }
    _bootstrap(extra, skipIfExists) {
        const from = this.templatePath('bootstrap');
        const to = this.destinationPath(this.options.destination);
        this.fs.copy(from, to, { ignore: skipIfExists });
        extra.forEach(x => this.fs.copy(`${from}/${x}`, `${to}/${x}`));
        skipIfExists.forEach(x => this.fs.exists(`${to}/${x}`) || this.fs.copy(`${from}/${x}`, `${to}/${x}`));
    }
    _beautify(filename) {
        this.fs.write(filename, beautify(this.fs.read(filename), {
            jslint_happy: true, preserve_newlines: false
        }));
    }
    _getLocationFromPath(path) {
        return (path || '').split('/').map((x) => kebabCase(x)).join('/');
    }
    _generateUseCase(x, options) {
        const dest = this.destinationPath(`${this.options.destination}/documentation/useCases/${x.name}.json`);
        if (this.fs.exists(dest)) {
            let data = this.fs.readJSON(dest);
            this.fs.copyTpl(this.templatePath('../../_base/templates/xmiUseCase.ejs'), dest, options);
            data = Object.assign(Object.assign({}, data), this.fs.readJSON(dest));
            this.fs.delete(dest);
            this.fs.writeJSON(dest, data);
        }
        else
            this.fs.copyTpl(this.templatePath('../../_base/templates/xmiUseCase.ejs'), dest, options);
    }
}
exports.XmiGeneratorBase = XmiGeneratorBase;
//# sourceMappingURL=xmiGeneratorBase.js.map