"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseControl = void 0;
class BaseControl {
    constructor(element) {
        this.element = element;
    }
}
exports.BaseControl = BaseControl;
//# sourceMappingURL=base.js.map