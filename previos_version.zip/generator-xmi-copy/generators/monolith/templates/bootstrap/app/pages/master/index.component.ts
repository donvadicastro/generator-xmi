import { Component } from '@angular/core';

@Component({
    selector: 'index',
    templateUrl: './index.component.html',
    styleUrls: ['./index.components.sass']
})
export class IndexComponent {
}
