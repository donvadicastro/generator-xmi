'use strict';
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.XmiGenerator = void 0;
const xmiPackage_1 = require("../../src/entities/xmiPackage");
const chalk_1 = __importDefault(require("chalk"));
const xmiCollaboration_1 = require("../../src/entities/xmiCollaboration");
const xmiActor_1 = require("../../src/entities/xmiActor");
const xmiScreen_1 = require("../../src/entities/ui/xmiScreen");
const xmiInterface_1 = require("../../src/entities/xmiInterface");
const xmiComponentFactory_1 = require("../../src/factories/xmiComponentFactory");
const xmiUseCase_1 = require("../../src/entities/xmiUseCase");
const xmiGeneratorBase_1 = require("../_base/xmiGeneratorBase");
const xmiInstanceSpecification_1 = require("../../src/entities/xmiInstanceSpecification");
const xmiComponent_1 = require("../../src/entities/xmiComponent");
const xmiBoundary_1 = require("../../src/entities/useCases/xmiBoundary");
const xmiEnumeration_1 = require("../../src/entities/xmiEnumeration");
const xmiDataType_1 = require("../../src/entities/xmiDataType");
const xmiClass_1 = require("../../src/entities/xmiClass");
const fs_1 = require("fs");
const path_1 = require("path");
const kebabCase = require('just-kebab-case');
const pascal = require('to-pascal-case');
// const prettier = require('prettier');
class XmiGenerator extends xmiGeneratorBase_1.XmiGeneratorBase {
    constructor() {
        super(...arguments);
        this.staleContent = [];
    }
    //TODO: requires Node > 10
    // _beautify(filename: string) {
    //     this.fs.write(filename, prettier.format(this.fs.read(filename), {
    //         parser: 'java', tabWidth: 4
    //     }));
    // }
    generate() {
        this._bootstrap([], ['.env']);
        this.log(chalk_1.default.green('Generate'));
        this._generate('', this.options.parser.packge);
        this.testFiles.forEach(x => this._beautify(x));
        this.generatedFiles.forEach(x => this._beautify(x));
    }
    end() {
        this.log('\r\n\r\nProject generated successfully.\r\nUpdate configuration to start using application:');
        this.log(chalk_1.default.green('DB connection:            ') + `${this.options.destination}/.env -> "db" section`);
        this.log(chalk_1.default.green('JIRA credentials:         ') + `${this.options.destination}/.env -> "jira" section`);
        this.log(chalk_1.default.green('Auth server connection:   ') + `${this.options.destination}/.env -> "keycloak" section`);
        if (this.staleContent.length) {
            this.log(chalk_1.default.yellow('\r\nStale content: '));
            this.staleContent.forEach(x => this.log(x));
        }
    }
    _generate(localPath, pkg) {
        const path = this.options.destination + '/src/main/java/com/generator/design' + localPath;
        const childPackages = ['components', 'contracts', 'enums', 'types', 'process', 'test'];
        const childComponents = [];
        const options = {
            auth: this.options.auth,
            factory: xmiComponentFactory_1.xmiComponentFactory,
            utils: {
                kebabCase: kebabCase,
                self: (x) => x
            }
        };
        pkg.children.filter((x) => x.name).forEach((x) => {
            this.log(`Processing "${x.name}" package element`);
            options.className = pascal(x.name);
            options.entity = x;
            if (x instanceof xmiActor_1.xmiActor) {
                // const destFileName = this.destinationPath(`${path}/components/generated/${x.name}.generated.ts`);
                // this.fs.copyTpl(this.templatePath('xmiActor.ejs'), destFileName, options);
                // this.generatedFiles.push(destFileName);
            }
            else if (x instanceof xmiBoundary_1.xmiBoundary) {
                // const destFileName = this.destinationPath(`${path}/components/generated/${x.name}.generated.ts`);
                // this.fs.copyTpl(this.templatePath('xmiActor.ejs'), destFileName, options);
                // this.generatedFiles.push(destFileName);
            }
            else if (x instanceof xmiEnumeration_1.xmiEnumeration) {
                const fileName = `${path}/enums/${x.namePascal}.java`;
                const destFileName = this.destinationPath(fileName);
                this.fs.copyTpl(this.templatePath('xmiEnumeration.java.ejs'), destFileName, options);
                this.generatedFiles.push(destFileName);
                this.enums.push({ path: localPath, url: this._getLocationFromPath(localPath), entity: x });
            }
            else if (x instanceof xmiInstanceSpecification_1.xmiInstanceSpecification) {
                // const baseClassFileName = this.destinationPath(`${path}/components/generated/${x.name}.generated.ts`);
                // const classFileName = this.destinationPath(`${path}/components/${x.name}.ts`);
                //
                // this.fs.copyTpl(this.templatePath('xmiClass.generated.java.ejs'), baseClassFileName, options);
                // this.generatedFiles.push(baseClassFileName);
                //
                // if(!this.fs.exists(classFileName)) {
                //     this.fs.copyTpl(this.templatePath('xmiClass.java.ejs'), classFileName, options);
                //     this.generatedFiles.push(classFileName);
                // }
                //
                // //store all non-generated content
                // childComponents.push(classFileName);
            }
            else if (x instanceof xmiComponent_1.xmiComponent) {
                // const interfaceFileName = this.destinationPath(`${path}/contracts/${x.name}.ts`);
                // const baseClassFileName = this.destinationPath(`${path}/components/generated/${x.name}.generated.ts`);
                // const classFileName = this.destinationPath(`${path}/components/${x.name}.ts`);
                // const classTestFileName = this.destinationPath(`${path}/components/${x.name}.test.ts`);
                //
                // this.fs.copyTpl(this.templatePath('xmiInterface.java.ejs'), interfaceFileName, options);
                // this.generatedFiles.push(interfaceFileName);
                //
                // this.fs.copyTpl(this.templatePath('components/component.generated.ejs'), baseClassFileName, options);
                // this.generatedFiles.push(baseClassFileName);
                // this.components.push({path: localPath, url: this._getLocationFromPath(localPath), entity: x});
                //
                // if(!this.fs.exists(classFileName)) {
                //     this.fs.copyTpl(this.templatePath('components/component.ejs'), classFileName, options);
                // }
                //
                // if(!this.fs.exists(classTestFileName)) {
                //     this.fs.copyTpl(this.templatePath('components/component.test.ejs'), classTestFileName, options);
                //     // this.generatedFiles.push(classTestFileName);
                // }
                //
                // //store all non-generated content
                // childComponents.push(classFileName);
                // childComponents.push(classTestFileName);
            }
            else if (x instanceof xmiDataType_1.xmiDataType) {
                const baseClassFileName = this.destinationPath(`${path}/types/${x.namePascal}.java`);
                this.fs.copyTpl(this.templatePath('xmiDataType.java.ejs'), baseClassFileName, options);
                this.generatedFiles.push(baseClassFileName);
                this.dataTypes.push({ path: localPath, url: this._getLocationFromPath(localPath), entity: x });
            }
            else if (x instanceof xmiClass_1.xmiClass) {
                const baseClassFileName = this.destinationPath(`${path}/components/generated/${x.namePascal}Base.java`);
                const classFileName = this.destinationPath(`${path}/components/${x.namePascal}.java`);
                const repositoryFileName = this.destinationPath(`${path}/repositories/${x.namePascal}Repository.java`);
                const controllerFileName = this.destinationPath(`${path}/controllers/${x.namePascal}Controller.java`);
                const classTestFileName = this.destinationPath(`${path}/components/${x.namePascal}.test.java`);
                this.fs.copyTpl(this.templatePath('xmiClass.generated.java.ejs'), baseClassFileName, options);
                this.generatedFiles.push(baseClassFileName);
                if (!this.fs.exists(classFileName)) {
                    this.fs.copyTpl(this.templatePath('xmiClass.java.ejs'), classFileName, options);
                }
                this.fs.copyTpl(this.templatePath('spring/repository.java.ejs'), repositoryFileName, options);
                this.fs.copyTpl(this.templatePath('spring/controller.java.ejs'), controllerFileName, options);
                // if(!this.fs.exists(classTestFileName)) {
                //     this.fs.copyTpl(this.templatePath('xmiClass.test.java.ejs'), classTestFileName, options);
                // }
                //store all non-generated content
                childComponents.push(classFileName);
                childComponents.push(classTestFileName);
                this.classes.push({ path: localPath, url: this._getLocationFromPath(localPath), entity: x });
            }
            else if (x instanceof xmiInterface_1.xmiInterface) {
                const interfaceFileName = this.destinationPath(`${path}/contracts/${x.namePascal}.java`);
                this.fs.copyTpl(this.templatePath('xmiInterface.java.ejs'), interfaceFileName, options);
                this.generatedFiles.push(interfaceFileName);
            }
            else if (x instanceof xmiCollaboration_1.xmiCollaboration) {
                // const diagramFileName = this.destinationPath(`${path}/process/${x.name}.ts`);
                // const apiRouterFileName = this.destinationPath(`${this.options.destination}/api/server/routes/${localPath}/router.ts`);
                // const apiActorFileName = this.destinationPath(`${this.options.destination}/api/server/routes/${localPath}/actor.ts`);
                // const apiControllerFileName = this.destinationPath(`${this.options.destination}/api/server/routes/${localPath}/controller.ts`);
                //
                // this.fs.copyTpl(this.templatePath('xmiCollaboration.ejs'), diagramFileName, options);
                //
                // this.fs.copyTpl(this.templatePath('api/diagram/router.ejs'), apiRouterFileName, options);
                // this.fs.copyTpl(this.templatePath('api/diagram/actor.ejs'), apiActorFileName, options);
                // this.fs.copyTpl(this.templatePath('api/diagram/controller.ejs'), apiControllerFileName, options);
                //
                // this.generatedFiles.push(diagramFileName);
                // this.generatedFiles.push(apiActorFileName);
                // this.collaborationDiagrams.push({path: localPath, url: this._getLocationFromPath(localPath), entity: x});
            }
            else if (x instanceof xmiScreen_1.xmiScreen) {
                // const appComponentRootPath = this.destinationPath(`${this.options.destination}/app/pages/screens/${localPath}`);
                // const screenComponentFileName = `${appComponentRootPath}/${x.name}/component.ts`;
                //
                // this.fs.copyTpl(this.templatePath('app/screen/component.ts.ejs'), screenComponentFileName, options);
                // this.fs.copyTpl(this.templatePath('app/screen/component.html.ejs'), `${appComponentRootPath}/${x.name}/component.html`, options);
                // this.fs.write(`${appComponentRootPath}/${x.name}/component.sass`, '');
                //
                // this.generatedFiles.push(screenComponentFileName);
                // this.screens.push({path: localPath, url: this._getLocationFromPath(localPath), entity: x});
            }
            else if (x instanceof xmiUseCase_1.xmiUseCase) {
                // this._generateUseCase(x, options);
            }
            else if (x instanceof xmiPackage_1.xmiPackage) {
                localPath || this.fs.copyTpl(this.templatePath('readme.ejs'), `${this.options.destination}/readme.md`, options);
                //clean generated content
                fs_1.existsSync(`${localPath}/${x.name}/components/generated`) && this.spawnCommandSync('rm', ['-rf', `${localPath}/${x.name}/components/generated`]);
                fs_1.existsSync(`${localPath}/${x.name}/contracts`) && this.spawnCommandSync('rm', ['-rf', `${localPath}/${x.name}/contracts`]);
                fs_1.existsSync(`${localPath}/${x.name}/enums`) && this.spawnCommandSync('rm', ['-rf', `${localPath}/${x.name}/enums`]);
                fs_1.existsSync(`${localPath}/${x.name}/types`) && this.spawnCommandSync('rm', ['-rf', `${localPath}/${x.name}/types`]);
                this._generate(`${localPath}/${x.name}`, x);
                childPackages.push(x.name);
            }
        });
        localPath && this._calculateDiff(path, childPackages, childComponents);
    }
    _calculateDiff(localPath, folders, componentFiles) {
        if (fs_1.existsSync(localPath)) {
            const dirs = fs_1.readdirSync(this.destinationPath(localPath)).filter(f => fs_1.statSync(path_1.join(localPath, f)).isDirectory());
            this.staleContent = this.staleContent.concat(dirs.filter(x => folders.indexOf(x) === -1).map(x => `(D) ${localPath}/${x}`));
        }
        const cmpFolder = path_1.join(localPath, 'components');
        if (fs_1.existsSync(cmpFolder)) {
            const files = fs_1.readdirSync(this.destinationPath(cmpFolder)).filter(f => fs_1.statSync(path_1.join(cmpFolder, f)).isFile());
            this.staleContent = this.staleContent.concat(files.filter(x => componentFiles.indexOf(this.destinationPath(path_1.join(cmpFolder, x))) === -1).map(x => `(F) ${localPath}/components/${x}`));
        }
    }
}
exports.XmiGenerator = XmiGenerator;
module.exports = XmiGenerator;
//# sourceMappingURL=index.js.map