import PubNub from 'pubnub';

export const pubnub = new PubNub({
    subscribeKey: "sub-c-c1e7157a-2c7e-11e8-8305-f27a6a4e1feb",
    publishKey: "pub-c-d404362a-65e0-4f2f-90ca-83b6fa885642",
    secretKey: "sec-c-YjBlMTlmNDAtYzlhYy00YzkyLWI5OGItYjk0OWU3ZTRlZmE5",
    ssl: true
});