'use strict';
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.XmiGenerator = void 0;
const xmiComponent_1 = require("../../src/entities/xmiComponent");
const xmiPackage_1 = require("../../src/entities/xmiPackage");
const chalk_1 = __importDefault(require("chalk"));
const xmiCollaboration_1 = require("../../src/entities/xmiCollaboration");
const xmiActor_1 = require("../../src/entities/xmiActor");
const xmiInterface_1 = require("../../src/entities/xmiInterface");
const xmiComponentFactory_1 = require("../../src/factories/xmiComponentFactory");
const xmiUseCase_1 = require("../../src/entities/xmiUseCase");
const xmiGeneratorBase_1 = require("../_base/xmiGeneratorBase");
const xmiClass_1 = require("../../src/entities/xmiClass");
const pascal = require('to-pascal-case');
class XmiGenerator extends xmiGeneratorBase_1.XmiGeneratorBase {
    generate() {
        this._bootstrap(['.editorconfig', '.eslintignore', '.gitignore', '.yo-rc.json'], []);
        this.log(chalk_1.default.green('Generate'));
        this._generate('', this.options.parser.packge);
        this.testFiles.forEach(x => {
            //this.spawnCommand('tsc', ['--project', this.options.destination, x]);
            this._beautify(x);
        });
        this.generatedFiles.forEach(x => this._beautify(x));
    }
    _generate(localPath, pkg) {
        const path = this.options.destination + '/design' + localPath;
        const options = {
            factory: xmiComponentFactory_1.xmiComponentFactory
        };
        pkg.children.filter((x) => x.name).forEach((x) => {
            this.log(`Processing "${x.name}" package element`);
            options.className = pascal(x.name);
            options.entity = x;
            if (x instanceof xmiActor_1.xmiActor) {
                const destFileName = this.destinationPath(`${path}/components/generated/${x.name}.generated.ts`);
                this.fs.copyTpl(this.templatePath('xmiActor.ejs'), destFileName, options);
                this.generatedFiles.push(destFileName);
            }
            if (x instanceof xmiInterface_1.xmiInterface) {
                const interfaceFileName = this.destinationPath(`${path}/contracts/${x.name}.ts`);
                this.fs.copyTpl(this.templatePath('xmiInterface.ejs'), interfaceFileName, options);
                this.generatedFiles.push(interfaceFileName);
            }
            if (x instanceof xmiClass_1.xmiClass || x instanceof xmiComponent_1.xmiComponent) {
                const interfaceFileName = this.destinationPath(`${path}/contracts/${x.name}.ts`);
                const baseClassFileName = this.destinationPath(`${path}/components/generated/${x.name}.generated.ts`);
                const classFileName = this.destinationPath(`${path}/components/${x.name}.ts`);
                this.fs.copyTpl(this.templatePath('xmiInterface.ejs'), interfaceFileName, options);
                this.generatedFiles.push(interfaceFileName);
                this.fs.copyTpl(this.templatePath('xmiClass.generated.ejs'), baseClassFileName, options);
                this.generatedFiles.push(baseClassFileName);
                if (!this.fs.exists(classFileName)) {
                    this.fs.copyTpl(this.templatePath('xmiClass.ejs'), classFileName, options);
                    this.generatedFiles.push(classFileName);
                }
            }
            if (x instanceof xmiCollaboration_1.xmiCollaboration) {
                const diagramFileName = this.destinationPath(`${path}/process/${x.name}.ts`);
                this.fs.copyTpl(this.templatePath('xmiCollaboration.ejs'), diagramFileName, options);
                this.generatedFiles.push(diagramFileName);
                this.collaborationDiagrams.push({ path: localPath, url: this._getLocationFromPath(localPath), entity: x });
            }
            if (x instanceof xmiUseCase_1.xmiUseCase) {
                this._generateUseCase(x, options);
            }
            if (x instanceof xmiPackage_1.xmiPackage) {
                localPath || this.fs.copyTpl(this.templatePath('readme.ejs'), `${this.options.destination}/readme.md`, options);
                this._generate(`${localPath}/${x.name}`, x);
            }
        });
    }
}
exports.XmiGenerator = XmiGenerator;
module.exports = XmiGenerator;
//# sourceMappingURL=index.js.map