"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.utils = void 0;
exports.utils = {
    decode: (message) => {
        const buf = new Buffer(message.value, "binary");
        try {
            return JSON.parse(buf.toString());
        }
        catch (e) {
            return null;
        }
    },
    encode: (data) => {
        return JSON.stringify(data);
    }
};
//# sourceMappingURL=utils.js.map