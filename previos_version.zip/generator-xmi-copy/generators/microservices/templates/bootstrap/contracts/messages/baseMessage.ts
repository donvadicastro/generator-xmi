export interface IMessageBase {
}
