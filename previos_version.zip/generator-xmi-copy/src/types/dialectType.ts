export type DialectType = 'js' | 'java';
