import xmiBase from "../entities/xmiBase";

export class xmiMessageEndpoint extends xmiBase {}