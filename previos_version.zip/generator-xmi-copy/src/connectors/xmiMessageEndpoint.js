"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.xmiMessageEndpoint = void 0;
const xmiBase_1 = __importDefault(require("../entities/xmiBase"));
class xmiMessageEndpoint extends xmiBase_1.default {
}
exports.xmiMessageEndpoint = xmiMessageEndpoint;
//# sourceMappingURL=xmiMessageEndpoint.js.map