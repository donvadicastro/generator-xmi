"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.XmiParser = void 0;
const object_path_1 = require("object-path");
const xmiComponentFactory_1 = require("./factories/xmiComponentFactory");
class XmiParser {
    constructor(data) {
        this.ELEMENTS_PATH = ['xmi:XMI', 'xmi:Extension', '0', 'elements', '0', 'element'];
        this.CONNECTORS_PATH = ['xmi:XMI', 'xmi:Extension', '0', 'connectors', '0', 'connector'];
        this.DIAGRAMS_PATH = ['xmi:XMI', 'xmi:Extension', '0', 'diagrams', '0', 'diagram'];
        this.PACKAGE_ROOT = ['xmi:XMI', 'uml:Model', '0', 'packagedElement', '0'];
        this.elements = [];
        this.connectors = [];
        this.packge = null;
        this.errors = [];
        this.data = data;
    }
    parse(dialect = 'js') {
        return __awaiter(this, void 0, void 0, function* () {
            //clean factory
            const factory = new xmiComponentFactory_1.xmiComponentFactory(dialect);
            this.connectors = object_path_1.get(this.data, this.CONNECTORS_PATH, [])
                .map((x) => factory.getConnector(x));
            this.elements = object_path_1.get(this.data, this.ELEMENTS_PATH, [])
                .map((x) => factory.get(x));
            this.packge = factory.get(object_path_1.get(this.data, this.PACKAGE_ROOT));
            this.diagrams = (object_path_1.get(this.data, this.DIAGRAMS_PATH, [])).map(x => factory.getDiagram(x));
            // update references
            yield factory.initialize();
            this.errors = factory.errors;
            return this.errors.length === 0;
        });
    }
    toConsole() {
        const output = {};
        if (this.packge) {
            output.Package = this.packge.toConsole();
        }
        if (this.errors.length) {
            output.Errors = this.errors;
        }
        return output;
    }
}
exports.XmiParser = XmiParser;
//# sourceMappingURL=xmiParser.js.map