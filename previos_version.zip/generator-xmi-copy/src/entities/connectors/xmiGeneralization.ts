import xmiBase from "../xmiBase";

export class xmiGeneralization extends xmiBase {
}
