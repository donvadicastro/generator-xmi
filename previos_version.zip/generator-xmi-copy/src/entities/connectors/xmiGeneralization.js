"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.xmiGeneralization = void 0;
const xmiBase_1 = __importDefault(require("../xmiBase"));
class xmiGeneralization extends xmiBase_1.default {
}
exports.xmiGeneralization = xmiGeneralization;
//# sourceMappingURL=xmiGeneralization.js.map