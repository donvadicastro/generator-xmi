"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.xmiProvided = void 0;
const xmiRequired_1 = require("./xmiRequired");
class xmiProvided extends xmiRequired_1.xmiRequired {
}
exports.xmiProvided = xmiProvided;
//# sourceMappingURL=xmiProvided.js.map