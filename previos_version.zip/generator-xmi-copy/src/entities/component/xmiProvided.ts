import {xmiRequired} from "./xmiRequired";

export class xmiProvided extends xmiRequired {}
