import {xmiAbstractClass} from "../base/xmiAbstractClass";

export class xmiActor extends xmiAbstractClass {
}
