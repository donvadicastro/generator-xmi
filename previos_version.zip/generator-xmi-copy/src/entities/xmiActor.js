"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.xmiActor = void 0;
const xmiAbstractClass_1 = require("../base/xmiAbstractClass");
class xmiActor extends xmiAbstractClass_1.xmiAbstractClass {
}
exports.xmiActor = xmiActor;
//# sourceMappingURL=xmiActor.js.map