import xmiBase from "./xmiBase";

export class xmiComment extends xmiBase {}
