"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.xmiScreen = void 0;
const xmiGUIElement_1 = require("./xmiGUIElement");
class xmiScreen extends xmiGUIElement_1.xmiGUIElement {
    constructor(raw, parent, factory) {
        super(raw, parent, factory);
    }
}
exports.xmiScreen = xmiScreen;
//# sourceMappingURL=xmiScreen.js.map