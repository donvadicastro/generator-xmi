"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.xmiBoundary = void 0;
const xmiAbstractClass_1 = require("../../base/xmiAbstractClass");
class xmiBoundary extends xmiAbstractClass_1.xmiAbstractClass {
}
exports.xmiBoundary = xmiBoundary;
//# sourceMappingURL=xmiBoundary.js.map