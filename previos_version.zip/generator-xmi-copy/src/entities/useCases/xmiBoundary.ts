import {xmiAbstractClass} from "../../base/xmiAbstractClass";

export class xmiBoundary extends xmiAbstractClass {}
