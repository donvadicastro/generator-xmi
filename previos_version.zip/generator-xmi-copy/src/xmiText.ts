import xmiBase from "./entities/xmiBase";

export class xmiText extends xmiBase {
}
